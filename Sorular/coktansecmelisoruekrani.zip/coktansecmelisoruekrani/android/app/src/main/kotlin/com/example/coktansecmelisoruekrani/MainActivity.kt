package com.example.coktansecmelisoruekrani

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
